<?php
include("header.php");
?>
    
    
     <div id="templatemo_main"><span class="main_top"></span> 
     	
        <div id="templatemo_content">
                
        	<h2>Transaction Details</h2>

        	<form id="form1" name="form1" method="post" action="">
        	  <table width="519" border="1">
        	    <tr>
        	      <td>Account number</td>
        	      <td>234560</td>
      	      </tr>
        	    <tr>
        	      <td>Transaction date</td>
        	      <td>26-05-2012</td>
      	      </tr>
        	    <tr>
        	      <td>Transaction Amount</td>
        	      <td>500</td>
      	      </tr>
        	    <tr>
        	      <td>Transaction Type</td>
        	      <td>Net banking</td>
      	      </tr>
        	    <tr>
        	      <td>Transaction Description</td>
        	      <td>charges</td>
      	      </tr>
      	    </table>
        	  <p>&nbsp;</p>
        	  <p>&nbsp;</p>
<p>&nbsp;</p>
        	  <p>&nbsp;</p>
       	  </form>
<div class="cleaner_h50"></div>
        </div><!-- end of content -->
            
            <div id="templatemo_sidebar">
            
                <h2>Our Services</h2>
                
                <ul class="templatemo_list">
                <li>Donec vitae dui nisi, ut facilisis massa.</li>
                <li>Ut at quam dui, ut lobortis justo.</li>
                <li>Vestibulum pretium convallis diam  amet.</li>
                <li>Curabitur ullamcorper nibh nisi, sed dolor.</li>
                <li>Ut tempor interdum orci ut ornare.</li>
                </ul>
              <div class="cleaner_h40"></div>
                
                <h2>&nbsp;</h2>
</div>
                
		<div class="cleaner"></div>
     </div>     <!-- end of main -->
    <div id="templatemo_main_bottom"></div><!-- end of main -->
    
    <?php
include("footer.php");
?>