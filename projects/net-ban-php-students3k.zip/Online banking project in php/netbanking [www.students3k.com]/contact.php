<?php
include("header.php");
?>
    
    <div id="templatemo_banner">
    
    			<span class="nav_bg"></span>
            
                <div id="one" class="contentslider">
                    <div class="cs_wrapper">
                        <div class="cs_slider">
                        
                            <div class="cs_article">
                            
                            	<div class="slider_content_wrapper">
                            	
                      				<div class="right">
                                        <h2>Suspendisse sed odio ut mi auctor </h2>
                                        <p>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam ac elit nec turpis vehicula posuere. Integer accumsan sagittis nisl in hendrerit. Aliquam pulvinar sodales lobortis.</p>
                                        
                                        <div class="button"><a href="#">More...</a></div>
                                    </div>
                                  <div class="left">
                                   <img src="images/slider/templatemo_slide01.jpg" alt="Image 01" />
                                    </div>
                                
                                </div>
                                                                
                            </div><!-- End cs_article -->
                            
                            <div class="cs_article">
                            
                            <div class="slider_content_wrapper">
                  				<div class="right">
                                    <h2>Cras at quam at eros viverra bibendum</h2>
                                    <p>Vivamus lacus magna, fermentum vel vestibulum non, consequat at augue. Nam et neque dolor, et pharetra metus. Mauris molestie purus et velit egestas id semper ante luctus. Nullam ut nunc ac sem venenatis facilisis.</p>
                                    
                                    <div class="button"><a href="#">More...</a></div>
                               	</div>
                              <div class="left">
                                <img src="images/slider/templatemo_slide02.jpg" alt="Image 02" />
                                </div>
                                </div>
                            </div><!-- End cs_article -->
                            
                            <div class="cs_article">
                            
                            <div class="slider_content_wrapper">
                  				<div class="right">
                                    <h2>Donec blandit quam nec velit vulputate</h2>
                                    <p>Integer sed nisi sapien, ut gravida mauris. Nam et tellus libero. Cras purus libero, dapibus nec rutrum in, dapibus nec risus. Ut interdum mi sit amet magna feugiat auctor. Sed sed fermentum tellus.</p>
                                    
                                    <div class="button"><a href="#">More...</a></div>
                               	</div>
                              <div class="left">
                                <img src="images/slider/templatemo_slide03.jpg" alt="Image 03" />
                                </div>
                                
                                </div>
                            </div><!-- End cs_article -->
                            
                            <div class="cs_article">
                            
                            <div class="slider_content_wrapper">
                                
                         		 <div class="right">
                                    <h2>Aenean porttitor orci id enim porttitor</h2>
                                    <p>Mauris laoreet malesuada nisi. Aliquam erat volutpat. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Quisque ultricies turpis sed arcu tincidunt elementum.</p>
                                    
                                    <div class="button"><a href="#">More...</a></div>
                               	</div>
                                <div class="left">
                                <img src="images/slider/templatemo_slide04.jpg" alt="Image 04" />
                                </div>
                                </div>
                                
                            </div><!-- End cs_article -->
                      
                        </div><!-- End cs_slider -->
                    </div><!-- End cs_wrapper -->
                </div><!-- End contentslider -->
                
                <!-- Site JavaScript -->
                <script type="text/javascript" src="js/jquery-1.3.1.min.js"></script>
                <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
                <script type="text/javascript" src="js/jquery.ennui.contentslider.js"></script>
                <script type="text/javascript">
                    $(function() {
                    $('#one').ContentSlider({
                    width : '970px',
                    height : '240px',
                    speed : 400,
                    easing : 'easeOutSine'
                    });
                    });
                </script>
                <script src="js/jquery.chili-2.2.js" type="text/javascript"></script>
                <script src="js/chili/recipes.js" type="text/javascript"></script>
                <div class="cleaner"></div>
   
        </div>
     <div id="templatemo_main"><span class="main_top"></span> 
     	
        <div id="templatemo_content">
                
        	<h2>Contact Information</h2>

        	<p>Cras euismod elit in magna consequat ac tristique turpis lobortis. Ut vitae sem quis neque rhoncus imperdiet id eleifend odio. Maecenas eget urna neque. Cras purus libero, dapibus nec rutrum in, dapibus nec risus. Ut interdum mi sit amet magna feugiat.</p>
        <div class="cleaner_h40"></div>
        
        <div class="col_w250 float_l">
            
           		<h6>Address One</h6>
220-440 Suspendisse sed odio,<br />
                Mauris mattis tincidunt, 14460<br />
                Etiam id libero ligula<br /><br />
                
                Tel: 022-077-0990<br />
                Fax: 022-055-0660<br />
          </div>
                
                <div class="col_w250 float_r">
           
                <h6>Address Two</h6>
                550-660   Phasellus enim magna,<br />
                Curabitur ac magna vitae, 13550<br />
                Donec consequat<br /><br />
                
                Tel: 044-033-0220<br />
                Fax: 044-022-0990<br /> 
          </div>
        
            <div class="cleaner_h50"></div>
            
            	<div id="contact_form">
            
                    <h4>Quick Contact Form</h4>
                    
                     <form method="post" name="contact" action="#"> 
                     
                            <label for="author">Name:</label> <input name="author" type="text" class="input_field" id="author" maxlength="60" /> 
                          	<div class="cleaner_h10"></div> 
                            
                            <label for="email">Email:</label> <input name="email" type="text" class="input_field" id="email" maxlength="60" /> 
                          	<div class="cleaner_h10"></div> 
                            
                            <label for="subject">Subject:</label> <input name="subject" type="text" class="input_field" id="subject" maxlength="60" /> 
                            <div class="cleaner_h10"></div> 
 
                            <label for="text">Message:</label> <textarea id="text" name="text" rows="0" cols="0" class="required"></textarea> 
                            <div class="cleaner_h10"></div> 
                        
                        	<input type="submit" class="submit_btn float_l" name="submit" id="submit" value="Send" /> 
                        	<input type="reset" class="submit_btn float_r" name="reset" id="reset" value="Reset" /> 
                                     
                    </form>

            </div>      

        	</div><!-- end of content -->
            
            <div id="templatemo_sidebar">
            
                <h2>Our Services</h2>
                
                <ul class="templatemo_list">
                <li>Donec vitae dui nisi, ut facilisis massa.</li>
                <li>Ut at quam dui, ut lobortis justo.</li>
                <li>Vestibulum pretium convallis diam  amet.</li>
                <li>Curabitur ullamcorper nibh nisi, sed dolor.</li>
                <li>Ut tempor interdum orci ut ornare.</li>
                </ul>
                
                <div class="button"><a href="services.html">More...</a></div>
                
                <div class="cleaner_h40"></div>
                
                <h2>Testimonial</h2>
                <blockquote>
                <p>In ac libero urna. Suspendisse sed odio ut mi auctor blandit. Duis luctus nulla metus. Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</p>
                
                <cite>Paul - <span>Senior Designer</span></cite>
                </blockquote>
            
            </div>
                
		<div class="cleaner"></div>
     </div>     <!-- end of main -->
    <div id="templatemo_main_bottom"></div><!-- end of main -->
    <?php
	include("footer.php");
	?>