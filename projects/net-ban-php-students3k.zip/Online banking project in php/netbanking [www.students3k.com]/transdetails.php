<?php
include("header.php");
?>
<div id="templatemo_main"><span class="main_top"></span> 
     	
<div id="templatemo_content">
     		 <h2 align="center">TRANSACTION DETAILS</h2>
         <table width="533" border="1">
               <tr>
                 <th width="254" scope="col"><div align="left">ACCOUNT NUMBER</div></th>
                 <th width="263" scope="col"><div align="center">5493535835</div></th>
               </tr>
               <tr>
                 <td><div align="left">TRANSACTION DATE</div></td>
                 <td><div align="center">26-2-2012</div></td>
               </tr>
               <tr>
                 <td><div align="left">TRANSACTION AMOUNT</div></td>
                 <td><div align="center">500</div></td>
               </tr>
               <tr>
                 <td><div align="left">TRANSACTION TYPE</div></td>
                 <td><div align="center">NET BANKING</div></td>
               </tr>
               <tr>
                 <td>TRANSACTION DESCRIPTION</td>
                 <td><div align="center">CHARGE OF NEFT</div></td>
               </tr>
      </table>
         <p>&nbsp;</p>
        
        <div class="cleaner_h30"></div>
  <div class="cleaner_h60"></div>
</div><!-- end of content -->
            
            <div id="templatemo_sidebar">
            
       <?php
	   include("myaccountssidebar.php");
	   ?>
                

                
                <div class="cleaner_h40"></div>
                
                <h2>Testimonial</h2>
                <blockquote>
                <p>In ac libero urna. Suspendisse sed odio ut mi auctor blandit. Duis luctus nulla metus. Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</p>
                
                <cite>David - <span>Web Specialist</span></cite>
                </blockquote>
            
            </div>
                
		<div class="cleaner"></div>
     </div>     <!-- end of main -->
    <div id="templatemo_main_bottom"></div><!-- end of main -->
    
    <?php
	include("footer.php");
	?>