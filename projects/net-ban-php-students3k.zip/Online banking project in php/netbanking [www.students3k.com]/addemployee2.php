<?php
include("header.php");
?>
<div id="templatemo_main"><span class="main_top"></span>
  <div id="templatemo_content">
    <table width="523" height="215" border="0">
      <tr>
        <th width="264" scope="col"><div align="left">EMPLOYEE NAME </div></th>
        <th width="172" scope="col"><input class="rightal" name="emid8" type="text" id="emid9" size="40" /></th>
      </tr>
      <tr>
        <th scope="row"><div align="left"><span class="leftal"> LOGIN ID </span></div></th>
        <td><input class="rightal" name="emid" type="text" id="emid" size="40" /></td>
      </tr>
      <tr>
        <th scope="row"><div align="left">PASSWORD</div></th>
        <td><input class="rightal" name="emid2" type="text" id="emid2" size="40" /></td>
      </tr>
      <tr>
        <th scope="row"><div align="left">CONFIRM PASSWORD</div></th>
        <td><input class="rightal" name="emid3" type="text" id="emid3" size="40" /></td>
      </tr>
      <tr>
        <th scope="row"></p>
          <label class="leftal" for="contno5"> 
            <div align="left">CONTACTNUMBER 
            </div>
          </label></th>
        <td><input class="rightal" name="emid4" type="text" id="emid4" size="40" /></td>
      </tr>
      <tr>
        <th scope="row"><div align="left"><span class="leftal">E-MAIL ID </span></div></th>
        <td><input class="rightal" name="emid5" type="text" id="emid5" size="40" /></td>
      </tr>
    </table>
  </div><!-- end of content -->
            
            <div id="templatemo_sidebar">
            
       <?php
	   include("myaccountssidebar.php");
	   ?>
                

                
                <div class="cleaner_h40"></div>
                
                <h2>Testimonial</h2>
                <blockquote>
                <p>In ac libero urna. Suspendisse sed odio ut mi auctor blandit. Duis luctus nulla metus. Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</p>
                
                <cite>David - <span>Web Specialist</span></cite>
                </blockquote>
            
            </div>
                
		<div class="cleaner"></div>
     </div>     <!-- end of main -->
    <div id="templatemo_main_bottom"></div><!-- end of main -->
    
    <?php
	include("footer.php");
	?>