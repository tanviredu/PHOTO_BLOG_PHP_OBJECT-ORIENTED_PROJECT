         <h2>My Accounts</h2>
                
                <ul class="templatemo_list">
                <li><a href="accountsummary.php">Accounts summary</a></li>
                <li><a href="ministatements.php">Mini statement</a></li>
                <li><a href="accdetails.php">Account details</a></li>
                <li><a href="stateacc.php">Statements of accounts</a>
                  <p>&nbsp;</p>
                </li>
                </ul>