<?php
include("header.php");
?>

     <div id="templatemo_main"><span class="main_top"></span>
       <div class="col_w420 float_l">
        	
         <h2>Web Development</h2>
            
                <div class="fl_img"><img src="images/calendar.png" alt="Calendar" /></div>
                <p><em>Morbi sed nulla ac est cursus suscipit eu ac lectus. Curabitur  ullamcorper nibh nisi, sed eleifend dolor. Pellentesque adipiscing  sollicitudin sapien nec aliquet.Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</em></p>
                
                <ul class="templatemo_list">
                    <li>Curabitur ullamcorper nibh nisi, sed eleifend dolor.</li>
                    <li>Pellentesque adipiscing sollicitudin sapien nec aliquet.</li>
                    <li>Vestibulum in lorem ante, id hendrerit magna.</li>
                    <li>Sed nec eros egestas nisl tincidunt aliquet at in est.</li>
                    <li>Morbi sed nulla ac est cursus suscipit eu ac lectus.</li>
                </ul>
                
       </div>
        
         <div class="col_w420 float_r">
        
           	<h2>Web Hosting</h2>
           	<div class="fl_img"><img src="images/sitemap.png" alt="Sitemap" /></div>
                <p><em>Donec lacus purus, pellentesque id vestibulum vitae, dapibus ac justo. Pellentesque habitant morbi tristique senectus et netus et malesuada fames turpis egestas.</em></p>
                
    <ul class="templatemo_list">
	                <li>Pellentesque quis odio quam, nec malesuada mauris.</li>
                    <li>Nam malesuada bibendum metus ac faucibus.</li>
                    <li>Fusce vitae ipsum ut nibh porta blandit sed vitae leo.</li>
                    <li>Mauris risus magna, blandit ac suscipit at, tristique id erat.</li>
                    <li>Vestibulum malesuada magna a nisi tempor interdum.</li>
                </ul>
   	   </div>
           
           	<div class="cleaner_h60"></div>
                   
        <div class="col_w420 float_l">
        
            <h2>Email Marketing</h2>
          	<div class="fl_img"><img src="images/note.png" alt="Note" /></div>
                <p><em>Vivamus interdum, tortor at pellentesque pulvinar, diam quam blandit  nulla, non faucibus nisi metus sit amet neque. Etiam eu ipsum a arcu  sodales consequat sit amet at orci.</em></p>
                
                <ul class="templatemo_list">
                    <li>In nec leo a odio semper vestibulum id euismod ante.</li>
                    <li>Sed fermentum nibh vitae turpis placerat sollicitudin.</li>
                    <li>Proin laoreet tellus sit amet nunc laoreet cursus.</li>
                    <li>Sed lobortis quam nec mauris vulputate suscipit.</li>
                    <li>Etiam sit amet ligula vel lacus mattis condimentum.</li>
                </ul>
                
   	   </div>
          
          <div class="col_w420 float_r">
        
            <h2>Banner Advertising</h2>
            <div class="fl_img"><img src="images/portfolio.png" alt="Porforlio" /></div>
                <p><em>Proin luctus placerat arcu, eget vehicula metus rhoncus ut. Fusce  pharetra pharetra venenatis. Sed condimentum ornare ipsum, nec gravida  sem sollicitudin quis.</em></p>
                
                 <ul class="templatemo_list">
                    <li>Nullam sit amet eros velit, vitae ultrices lorem. </li>
                    <li>Fusce gravida sem fermentum felis egestas semper.</li>
                    <li>Quisque hendrerit sem id ligula gravida eleifend.</li>
                    <li>Praesent rhoncus sem non urna euismod posuere.</li>
                    <li>Ut vehicula leo in nunc mollis sed pharetra purus.</li>
            </ul>
       </div>
                
           <div class="cleaner"></div>
</div>     <!-- end of main -->
    <div id="templatemo_main_bottom"></div><!-- end of main -->
    
    <?php
	include("footer.php");
	?>