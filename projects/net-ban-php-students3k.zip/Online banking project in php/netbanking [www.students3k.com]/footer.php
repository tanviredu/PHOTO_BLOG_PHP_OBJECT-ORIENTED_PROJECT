
    <div id="templatemo_footer">
    
    Designed by SOUDHA BANU </div> <!-- end of templatemo_footer -->
</div> <!-- end of wrapper -->

</body>
</html>