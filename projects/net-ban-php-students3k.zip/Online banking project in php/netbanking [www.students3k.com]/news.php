<?php
include("header.php")
?>
    
     <div id="templatemo_main"><span class="main_top"></span> 
     	
        <div id="templatemo_content">
     		<div class="news_box">
                    <h2>Simple PHP Shopping  Script</h2>		
                    <div class="news_info">May 30, 2048 | <a href="http://www.templatemo.com/page/1" target="_parent">Web Development</a> by <a href="http://www.templatemo.com" target="_parent">Ladia</a></div>
                    
                    <div class="image_wrapper fr_img"><img src="images/templatemo_image_03.jpg" alt="Image 03" /></div>
                    
                    <p>Curabitur ullamcorper neque et justo aliquet at pretium orci  scelerisque. Mauris sodales tristique dignissim. Phasellus ut augue  nibh. Aliquam vel libero sit amet mauris posuere ullamcorper  sollicitudin ac eros. Vestibulum auctor euismod mi et tincidunt. Mauris  vitae ipsum diam, sagittis tempor velit.</p>
                    <div class="cleaner"></div>
                    <a href="#">Continue reading...</a> | <a href="#">163 comments</a>
                </div>
                
                <div class="news_box">
                    <h2>Clean CSS Template Tips</h2>
                    <div class="news_info">May 24, 2048 |  <a href="http://www.templatemo.com/page/1" target="_parent">Web Template</a> by <a href="http://www.templatemo.com" target="_parent">James</a></div>
                    
                    <div class="image_wrapper fr_img"><img src="images/templatemo_image_04.jpg" alt="Image 04" /></div>
                    
                    <p>Morbi sed nulla ac est cursus suscipit eu ac lectus. Curabitur  ullamcorper nibh nisi, sed eleifend dolor. Pellentesque adipiscing  sollicitudin sapien nec aliquet. Cras rutrum ullamcorper metus, vitae  consectetur dolor vulputate a. Sed nec eros egestas nisl tincidunt  aliquet at in est. Proin luctus placerat arcu, eget vehicula metus  rhoncus ut. Fusce pharetra pharetra venenatis.</p>
                    <div class="cleaner"></div>
                    <a href="#">Continue reading...</a> | <a href="#">246 comments</a>
                </div>
                
                <div class="news_box">
                    <h2>Banner Awards</h2>
                    
                    <div class="news_info">May 14, 2048 | <a href="http://www.templatemo.com/page/1" target="_parent">Graphic Design</a> by <a href="http://www.templatemo.com" target="_parent">Smith</a></div>
                    
                    <div class="image_wrapper fr_img"><img src="images/templatemo_image_05.jpg" alt="Image 05" /></div>
                    
                    <p>Nam malesuada bibendum metus ac faucibus. Integer semper, felis eget  imperdiet commodo, nunc augue luctus sem, a tincidunt dolor nisl vel  massa. Vivamus interdum, tortor at pellentesque pulvinar, diam quam  blandit nulla, non faucibus nisi metus sit amet neque. Etiam eu ipsum a  arcu sodales consequat sit amet at orci. Mauris blandit euismod lobortis.</p>
                    <div class="cleaner"></div>
                    <a href="#">Continue reading...</a> | <a href="#">187 comments</a>
				</div>                

        	</div><!-- end of content -->
            
            <div id="templatemo_sidebar">
            
                <h2>Our Services</h2>
                
                <ul class="templatemo_list">
                <li>Donec vitae dui nisi, ut facilisis massa.</li>
                <li>Ut at quam dui, ut lobortis justo.</li>
                <li>Vestibulum pretium convallis diam  amet.</li>
                <li>Curabitur ullamcorper nibh nisi, sed dolor.</li>
                <li>Ut tempor interdum orci ut ornare.</li>
                </ul>
                
            <div class="button"><a href="services.html">More...</a></div>
                
                <div class="cleaner_h40"></div>
                
                <h2>Testimonial</h2>
                <blockquote>
                <p>In ac libero urna. Suspendisse sed odio ut mi auctor blandit. Duis luctus nulla metus. Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</p>
                
                <cite>John - <span>Marketing Director</span></cite>
                </blockquote>
            
            </div>
                
		<div class="cleaner"></div>
     </div>     <!-- end of main -->
    <div id="templatemo_main_bottom"></div><!-- end of main -->
    
    <?php
	include("footer.php");
	?>