<?

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE ALBUM LANGUAGE FILE
include "../lang/lang_".$global_lang."_album.php";

// INCLUDE ALBUM CLASS FILE
include "../include/class_album.php";

// INCLUDE ALBUM FUNCTION FILE
include "../include/functions_album.php";

?>