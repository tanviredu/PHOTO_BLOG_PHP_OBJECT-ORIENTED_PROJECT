<?
header("Location: admin_login.php");
exit();
?>