<?

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE CHAT LANGUAGE FILE
include "../lang/lang_".$global_lang."_chat.php";

?>