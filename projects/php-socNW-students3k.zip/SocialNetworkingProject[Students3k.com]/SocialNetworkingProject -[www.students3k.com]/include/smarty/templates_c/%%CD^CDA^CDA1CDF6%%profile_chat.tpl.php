<?php /* Smarty version 2.6.14, created on 2012-03-03 02:14:39
         compiled from profile_chat.tpl */ ?>
