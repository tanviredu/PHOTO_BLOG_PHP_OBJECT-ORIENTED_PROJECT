<?
header("Location: home.php");
exit();
?>