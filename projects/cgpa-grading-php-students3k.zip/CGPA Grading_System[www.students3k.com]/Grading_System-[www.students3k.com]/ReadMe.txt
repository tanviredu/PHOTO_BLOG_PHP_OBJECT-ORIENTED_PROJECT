Title: online grading system 2.0
Description: This greatly helps to those who currently developing an online online grading system, this i made for my students to view thier grades via online, it also showcases the use of css(cascading style sheet), javascript,php and odbc connection of databases.

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

www.students3k.com